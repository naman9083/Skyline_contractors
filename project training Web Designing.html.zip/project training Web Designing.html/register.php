<?php
$showAlert = false;
$showError = false;
if($_SERVER["REQUEST_METHOD"] == "POST"){
    include 'config.php';
    $username = $_POST["username"];
    $cno=$_POST["cno"];
    $email=$_POST["email"];
    $password = $_POST["password"];
    $cpassword = $_POST["cpassword"];
    // $exists=false;

    // Check whether this username exists
    $existSql = "SELECT * FROM customer1 WHERE username = '$username'";
    $result = mysqli_query($conn, $existSql);
    $numExistRows = mysqli_num_rows($result);
    if($numExistRows > 0){
        // $exists = true;
        $showError = "Username Already Exists";
    }
    else{
        // $exists = false; 
        if(($password == $cpassword)){
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $sql = "INSERT INTO customer1 ( username, cno, email, password) VALUES ('$username', '$cno','$email', '$hash')";
            $result = mysqli_query($conn, $sql);
            if ($result){
                $showAlert = true;
            }
        }
        else{
            $showError = "Passwords do not match";
        }
    }
}
    
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>regestration</title>
    <style>
        *{
            margin: 0;
            padding: 0;
            font-family: sans-serif;
            box-sizing: border-box;
        }
        .header{
    font-family:Verdana, Geneva, Tahoma, sans-serif;
    font-weight:550;
    min-height: 3;
    width: 100%;
    background-color: rgb(247, 242, 242);
    background-size: cover;
    background-position:center ;
    position: relative;
    border-bottom-color: coral;
    }
nav{
      display:flex ;
       padding: 0;
       justify-content: space-between;
       align-items: center;
    }
nav img{
    width: 150px;
    }
.nav-link{
        flex: 1;
        text-align: right;
    }
.nav-link ul li{
        list-style: none;
        display: inline-block;
        padding: 6px 10px;
        position: relative;
    }
.nav-link ul li a{
        color: #f4b136;
        text-decoration: none;
        font-size: 13px;
    }
.nav-link ul li::after{
        content: '';
        width: 0%;
        height: 2px;
        background: #f4b136;
        display: block;
        margin: auto;
        transition: 0.5s;
    }
.nav-link ul li:hover::after{
        width: 100%;
    }
        .body{
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            height: 100vh;
            background-image: url(https://image.freepik.com/free-photo/food-presentation-background-organic-various-exotic-species-black-slate-board_42124-532.jpg);
            background-size: cover;
        }
        form{
            margin-top: 50px;
            text-align: center;
        }
        h1{
            color: white;
            float: left;
        font-size: 38px;
        border-bottom: 6px solid #f4b136;
        margin-bottom: 5px;
        padding: 0 0;
        }
        input{
            color: white;
            display: block;
            width: 350px;
            height: 40px;            
            margin: 20px;
            border: none;
            font-size: 20px;
            border-bottom: 1px solid #f4b136;
            background: transparent;
        }
            button{
        width: 100%;
        background: none;
        border: 2px solid #f4b136;
        color: white;
        padding:5px;
        font-size: 18px;
        margin: 12px 0;
        cursor: pointer;
        }
        button:hover{
        border: 1px solid #fff;
    background: #f4b136;
    transition: 1s;
      }
    </style>
    
</head>
<body>

    <?php
    if($showAlert){
    echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Your account is now created and you can login
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div> ';
    }
    if($showError){
    echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Error!</strong> '. $showError.'
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div> ';
    }
    ?>
    <section class="header" >
        <nav>
            <a href="home page.html" target="_blank"><img src=""></a>
            <div class="nav-link">
                <ul>
                    <li><a href="homepage.php">HOME</a></li>
                    <li><a href="file:///Users/apple/Documents/project.html/resturant.html">RESTURANTS</a></li>
                    <li><a href="">OFFERS</a></li>
                    <li><a href="login.php">SIGN IN</a></li>
                    <li><a href="">Help</a></li>
                </ul>
            </div>
        </nav>
</section>
<section class="body">
    
    <form method="post" action="register.php">
        <h1 >Sign up</h1><br><br><br><br>
        <input type="text" name="username" placeholder="Username">
        <input type="text" name="cno" placeholder="Enter Contact Number">
        <input type="email" name="email" placeholder="Enter E-mail">
        <input type="password" name="password" placeholder="Enter Password">
        <input type="password" name="cpassword" placeholder="Confirm Password">
        <button type="submit" value="submit">Submit</button>
    </form>
     <br>
    <div class="link">
        <p1 style="color: #f4b136;">Already a member? </p1><a href="file:///C:/xampp/htdocs/login.html">Sign in here</a>
     </div>
    </section>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    
</body>
</html>